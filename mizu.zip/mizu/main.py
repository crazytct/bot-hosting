import discord 
from discord.ext import commands

from keep_alive import keep_alive

bot = commands.Bot(command_prefix='!', intents=discord.Intents.all(), case_insensitive=True)

@bot.event
async def on_ready():
  print("logged in!")

@bot.command()
async def ping(arcelia):
  await arcelia.send("pong!")

@bot.command()
async def hii(ctx):
  await ctx.send("hello")



@bot.command()
async def say(ctx, message):
  embed = discord.Embed(title="", description=message, color=discord.Color.pink())
  embed.set_footer(text=f"Sent by: {ctx.author.name}")
  await ctx.message.delete()
  await ctx.send(embed=embed)



keep_alive()
bot.run("MTE2MjYzOTY4OTM2MzIyNjY2NQ.Gebo7X.enJz6reUoaRqgBpavApImjnZtAq0ODGooIbAgQ")

